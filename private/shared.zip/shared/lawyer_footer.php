
   </div>
      </div>
    </div>
    <!-- END: Content-->
    
    

    </div>
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">
      <p class="clearfix blue-grey lighten-2 mb-0">
      <span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; <?php echo date('Y') ?><a class="text-bold-800 grey darken-2" href="#" target="_blank">RJSC,</a>All rights Reserved</span><span class="float-md-right d-none d-md-block">Designed by All-Tech Systems & Co.<i class="feather-heart pink"></i></span>
        <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="feather icon-arrow-up"></i></button>
      </p>
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo url_for('js/jquery.js') ?>"></script>
    <script src="<?php echo url_for('js/vendors.min.js') ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo url_for('js/jquery.steps.min.js') ?>"></script>
    <script src="<?php echo url_for('js/jquery.validate.min.js') ?>"></script>
    <!-- END: Page Vendor JS-->

    
    <!-- BEGIN: Theme JS-->
    <script src="<?php echo url_for('js/app-menu.min.js') ?>"></script>
    <script src="<?php echo url_for('js/app.min.js') ?>"></script>
    <script src="<?php echo url_for('js/components.min.js') ?>"></script>
    <script src="<?php echo url_for('js/customizer.min.js') ?>"></script>
    <script src="<?php echo url_for('js/footer.min.js') ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo url_for('js/wizard-steps.min.js') ?>"></script>
    <!-- END: Page JS-->

  </body>
  <!-- END: Body-->

</html>